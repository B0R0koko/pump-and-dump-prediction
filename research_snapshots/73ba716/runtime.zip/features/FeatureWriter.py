from typing import List
from core.time_utils import NamedTimeDelta

REGRESSOR_OFFSETS: List[NamedTimeDelta] = [
    NamedTimeDelta.FIVE_MINUTES,
    NamedTimeDelta.FIFTEEN_MINUTES,
    NamedTimeDelta.ONE_HOUR,
    NamedTimeDelta.TWO_HOURS,
    NamedTimeDelta.FOUR_HOURS,
    NamedTimeDelta.TWELVE_HOURS,
    NamedTimeDelta.ONE_DAY,
    NamedTimeDelta.TWO_DAYS,
    NamedTimeDelta.ONE_WEEK,
    NamedTimeDelta.TWO_WEEKS,
]
