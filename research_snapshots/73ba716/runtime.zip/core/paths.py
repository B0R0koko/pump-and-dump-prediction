"""Historical research paths with the current installer data directory."""
from pumps_and_dumps.core.paths import (
    get_root_dir, DATA_DIR, RAW_DATA_DIR, TRANSFORMED_DATA_DIR, FEATURE_DIR,
    BINANCE_SPOT_RAW_TRADES, BINANCE_SPOT_RAW_KLINES, BINANCE_SPOT_HIVE_TRADES,
)
SQLITE_URL = f"sqlite:///{DATA_DIR / 'studies.db'}"
